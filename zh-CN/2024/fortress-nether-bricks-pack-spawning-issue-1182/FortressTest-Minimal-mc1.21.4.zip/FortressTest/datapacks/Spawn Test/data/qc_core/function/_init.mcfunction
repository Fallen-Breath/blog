scoreboard players set #init Variables 1
scoreboard players set start_time Variables 0
scoreboard players set end_time Variables 0

scoreboard players set benchmarking Variables 0

difficulty peaceful