execute unless score benchmarking Variables matches 0 store result score end_time Variables run time query gametime

execute unless score benchmarking Variables matches 0 run difficulty peaceful

# carpet command
execute unless score benchmarking Variables matches 0 run spawn tracking stop
#execute unless score benchmarking Variables matches 0 run lifetime tracking stop
execute unless score benchmarking Variables matches 0 run tick sprint stop

execute unless score benchmarking Variables matches 0 run schedule clear qc:beep

scoreboard players set benchmarking Variables 0