function qc:stop_test
function qc:start_test