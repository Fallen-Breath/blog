execute unless score benchmarking Variables matches 1.. store result score start_time Variables run time query gametime

execute unless score benchmarking Variables matches 1.. run difficulty hard

# carpet command
execute unless score benchmarking Variables matches 1.. run spawn tracking start
#execute unless score benchmarking Variables matches 1.. run lifetime tracking start
execute unless score benchmarking Variables matches 1.. run tick sprint 216000

execute unless score benchmarking Variables matches 1.. run schedule function qc:beep 216000t

scoreboard players set benchmarking Variables 1