scoreboard objectives add Variables dummy
execute unless score #init Variables matches 1 run function qc_core:_init

carpet commandSpawn true
#carpet commandLifeTime true

function qc:end_test