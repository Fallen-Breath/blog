fill -55 77 73 -83 77 45 minecraft:air replace #minecraft:wool_carpets
fill -83 73 45 -55 73 73 minecraft:air replace #minecraft:wool_carpets
fill -83 69 45 -55 69 73 minecraft:air replace #minecraft:wool_carpets

fill -55 76 73 -83 76 45 minecraft:air replace minecraft:nether_bricks
fill -83 72 45 -55 72 73 minecraft:air replace minecraft:nether_bricks
fill -83 68 45 -55 68 73 minecraft:air replace minecraft:nether_bricks

fill -55 76 73 -83 76 45 minecraft:air replace minecraft:stone_bricks
fill -83 72 45 -55 72 73 minecraft:air replace minecraft:stone_bricks
fill -83 68 45 -55 68 73 minecraft:air replace minecraft:stone_bricks

